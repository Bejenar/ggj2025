using System;
using Cysharp.Threading.Tasks;

namespace _Project.Source.Util
{
    public static class InteractorExtensions
    {
    }
}